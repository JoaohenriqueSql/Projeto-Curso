<?php 
  require('connection.php'); 
  session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tech Link</title>
    <link rel="stylesheet" href="CSS/style.css" />
    <link rel="stylesheet" href="CSS/style-query.css" />
  </head>

  <body>
    <header>
      <nav>
        <a class="logo" href="/">Tech Link</a>
        <div class="mobile-menu">
          <div class="line1"></div>
          <div class="line2"></div>
          <div class="line3"></div>
        </div>
        <ul class="nav-list">
          <li><a href="#">Início</a></li>
          <li><a href="#">Sobre</a></li>
          <li><a href="#">Projetos</a></li>
          <li><a href="#">Contato</a></li>
          <?php 
    
            if(isset($_SESSION['logged_in']) && $_SESSION['logged_in']==true)
            {
              echo"
                <div class='user'>
                Bem Vindo $_SESSION[username] | <a href='logout.php' style='color: red; text-transform: uppercase;'>SAIR <ion-icon name='log-out-outline'></ion-icon> </a>
                </div>
              ";
            }
            else
            {
              echo"
              <div class='sign-in-up'>
                <button type='button' onclick=\"popup('login-popup')\">Entrar <ion-icon name='log-in-outline'></ion-icon> </button>
                <button type='button' onclick=\"popup('register-popup')\">Registrar-se</button>
              </div>
              ";

            }

          ?>
        </ul>
      </nav>
    </header>

    <div class="popup-container" id="login-popup">
    <div class="popup">
      <form method="POST" action="login_register.php">
        <h2>
          <span>Login de Usuário</span>
          <button type="reset" onclick="popup('login-popup')">X</button>
        </h2>
        <input type="text" placeholder="email ou nome de usuário" name="email_username" required>
        <input type="password" placeholder="senha" name="password" required>
        <button type="submit" class="login-btn" name="login">Entrar</button>
      </form>
      <div class="forgot-btn">
        <button type="button" onclick="forgotPopup()">Esqueceu a senha ?</button>
      </div>
    </div>
  </div>

<!-- campo modal registrar-se -->
  <div class="popup-container" id="register-popup">
    <div class="register popup">
      <form method="POST" action="login_register.php">
        <h2>
          <span>Criar Conta</span>
          <button type="reset" onclick="popup('register-popup')">X</button>
        </h2>
        <input type="text" placeholder="Nome completo" name="fullname" required>
        <input type="text" placeholder="Nome de usuário" name="username" required>
        <input type="email" placeholder="E-mail" name="email" required>
        <input type="password" placeholder="Senha" name="password" required>
        <button type="submit" class="register-btn" name="register">Criar</button>
      </form>
    </div>
  </div>

<!-- campo modal recuperar senha -->
  <div class="popup-container" id="forgot-popup">
    <div class="forgot popup">
      <form method="POST" action="forgotpassword.php">
        <h2>
          <span>Alterar Senha</span>
          <button type="reset" onclick="popup('forgot-popup')">X</button>
        </h2>
        <input type="text" placeholder="E-mail" name="email">
        <button type="submit" class="reset-btn" name="send-reset-link">Enviar Link</button>
      </form>
    </div>
  </div>



    <div class="onda">
      <img src="img-elementos/onda.svg">
    </div>

    <div class="pessoa">
      <img src="img-elementos/pessoa.svg">
    </div>


          <div class="leading">
            <div class="titulo">
              <h1>Segurança da Informação</h1>
            </div>

            <div class="sub-titulo">
              <h4>Um site seguro e confiável onda você pode conferir assuntos sobre segurança digital e como se proteger seguindo os nossos temas abordados</h4>
            </div>

          </div>


          <div class="introducao">
            <div class="cards-container">
              <main class="cards">
                <section class="card contact">
                    <div class="icon">
                        <img src="assets/Chat.png" alt="Contact us.">
                    </div>
                    <h3>Informação</h3>
                    <span>Dados e informações relativas sobre a lei LGPD nos países.</span>
                </section>
                <section class="card shop">
                    <div class="icon">
                        <img src="assets/Bag.png" alt="Shop here.">
                    </div>
                    <h3>Senhas</h3>
                    <span>Tipos de senhas mais usadas e sobre o gerador de senhas.</span>
                </section>
                <section class="card about">
                    <div class="icon">
                        <img src="assets/Play.png" alt="About us.">
                    </div>
                    <h3>Público</h3>
                    <span>Pessoas com base em midias sociais, tem maior impacto.</span>
                </section>
              </main>
            </div>

            <h2>Segurança Digital aborda muitos conceitos de sistemas de senhas e falta de informação ao publico.</h2>

          </div>


          <div class="onda2">
            <img src="img-elementos/onda2.svg">
          </div>



          <div class="onda3">
            <img src="img-elementos/onda3.svg">
          </div>

          <div class="pessoa2">
            <img src="img-elementos/pessoa2.svg">
          </div>

          <div class="blob">
            <img src="img-elementos/blob.svg">
          </div>


  <script src="JS/script.js"></script>
  </body>
</html>