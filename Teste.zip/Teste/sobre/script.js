var options = {
    strings: ["<i>First</i> sentence.", "&amp; a second sentence.", "hello"],
    typeSpeed: 20
  }
  
  var typed = new Typed(".typed_text", options);