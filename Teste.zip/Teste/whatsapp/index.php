<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="keyframes.css">
  <title>WhatsApp</title>
</head>
<body>

  <div class="wrapper">
    <div class="devices">
      <div class="marvel-device iphone8 black" id="device-1">
        <div class="top-bar"></div>
        <div class="sleep"></div>
        <div class="volume"></div>
        <div class="camera"></div>
        <div class="sensor"></div>
        <div class="speaker"></div>
        <div class="home"></div>
        <div class="screen">
          <div class="screen-container">
            <div class="status-bar">
              <div class="time"></div>
              <div class="battery">
                <i class="zmdi zmdi-battery"></i>
              </div>
              <div class="network">
                <i class="zmdi zmdi-network"></i>
              </div>
              <div class="phone-missed">
                <i class="zmdi zmdi-phone-missed"></i>
              </div>
              <div class="wifi">
                <i class="zmdi zmdi-wifi-alt"></i>
              </div>
              <div class="github">
                <i class="zmdi zmdi-github"></i>
              </div>
              <div class="drop-box">
                <i class="zmdi zmdi-dropbox"></i>
              </div>
            </div>
            <div class="chat">
              <div class="chat-container">
                <div class="user-bar">
                  <div class="app-name">
                    <h3>WhatsApp</h3>
                  </div>
                  <div class="actions more">
                    <i class="zmdi zmdi-more-vert"></i>
                  </div>
                  <div class="actions search">
                    <i class="zmdi zmdi-search"></i>
                  </div>
                </div>
                <div class="tab-bar">
                  <div class="photo">
                    <i class="zmdi zmdi-camera"></i>
                  </div>
                  <ul>
                    <li class="active">Conversas</li>
                    <li>Status</li>
                    <li>Chamadas</li>
                  </ul>
                </div>
                <div class="contacts">
                  <div class="contacts-container">
                    <div class="contact">
                      <div class="avatar">
                        <img src="nophoto.png" alt="no photo" />
                      </div>
                      <div class="contact-name">
                        <strong>Mãe</strong>
                        <span class="tick read">
                          <i class="zmdi zmdi-check"></i>
                          <i class="zmdi zmdi-check"></i>
                        </span>
                        <p>Te vejo amanhã</p>
                        <span class="metadata">
                          <span class="time">2:40 PM</span>
                        </span>
                      </div>
                    </div>
                    <div class="contact">
                      <div class="avatar">
                        <img src="nophoto.png" alt="no photo" />
                      </div>
                      <div class="contact-name">
                        <strong>Pai</strong>
                        <span class="tick">
                          <i class="zmdi zmdi-check"></i>
                          <i class="zmdi zmdi-check"></i>
                        </span>
                        <p>Fica pra proxima meu véio...</p>
                        <span class="metadata">
                          <span class="time">2:38 PM</span>
                        </span>
                      </div>
                    </div>
                    <div class="contact">
                      <div class="avatar">
                        <img src="nophoto.png" alt="no photo" />
                      </div>
                      <div class="contact-name">
                        <strong>Pablo Japaratuba</strong>
                        <span class="tick read">
                          <i class="zmdi zmdi-check"></i>
                          <i class="zmdi zmdi-check"></i>
                        </span>
                        <p>Tudo bem! até mais</p>
                        <span class="metadata">
                          <span class="time">3:35 PM</span>
                        </span>
                      </div>
                    </div>
                    <div class="contact active">
                      <div class="overlay-click"></div>
                      <div class="avatar">
                        <img src="avatar.jpg" alt="no photo" />
                      </div>
                      <div class="contact-name">
                        <strong>(43)99910-1010</strong>
                        <span class="tick read">
                          <i class="zmdi zmdi-check"></i>
                          <i class="zmdi zmdi-check"></i>
                        </span>
                        <p>Tá podendo falar?</p>
                        <span class="metadata">
                          <span class="time">9:34 PM</span>
                        </span>
                      </div>
                    </div>
                    <div class="contact">
                      <div class="avatar">
                        <img src="nophoto.png" alt="no photo" />
                      </div>
                      <div class="contact-name">
                        <strong>Edson</strong>
                        <span class="tick read">
                          <i class="zmdi zmdi-check"></i>
                          <i class="zmdi zmdi-check"></i>
                        </span>
                        <p>a festa foi incrível cara</p>
                        <span class="metadata">
                          <span class="time">1:22 PM</span>
                        </span>
                      </div>
                    </div>
                    <div class="contact">
                      <div class="avatar">
                        <img src="nophoto.png" alt="no photo" />
                      </div>
                      <div class="contact-name">
                        <strong>Bruna Amorim</strong>
                        <span class="tick">
                          <i class="zmdi zmdi-phone-missed red"></i>
                        </span>
                        <p>Chamada de voz perdida</p>
                        <span class="metadata">
                          <span class="time">6:21 PM</span>
                        </span>
                      </div>
                    </div>
                    <div class="contact">
                      <div class="avatar">
                        <img src="nophoto.png" alt="no photo" />
                      </div>
                      <div class="contact-name">
                        <strong>Adriano</strong>
                        <span class="tick">
                          <i class="zmdi zmdi-check"></i>
                          <i class="zmdi zmdi-check"></i>
                        </span>
                        <p>Que horas você pega o voo para São Paulo?</p>
                        <span class="metadata">
                          <span class="time">7:51 PM</span>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
        
      </div>

      <div class="marvel-device iphone8 black" id="device-2">
        <div class="top-bar"></div>
        <div class="sleep"></div>
        <div class="volume"></div>
        <div class="camera"></div>
        <div class="sensor"></div>
        <div class="speaker"></div>
        <div class="home"></div>
        <div class="screen">
          <div class="screen-container">
            <div class="status-bar">
              <div class="time"></div>
              <div class="battery">
                <i class="zmdi zmdi-battery"></i>
              </div>
              <div class="network">
                <i class="zmdi zmdi-network"></i>
              </div>
              <div class="phone-missed">
                <i class="zmdi zmdi-phone-missed"></i>
              </div>
              <div class="wifi">
                <i class="zmdi zmdi-wifi-alt"></i>
              </div>
              <div class="github">
                <i class="zmdi zmdi-github"></i>
              </div>
              <div class="drop-box">
                <i class="zmdi zmdi-dropbox"></i>
              </div>
            </div>
            <div class="chat">
              <!--campo conversa-->
              <div class="chat-container">
                <div class="user-bar">
                  <div class="back">
                    <i class="zmdi zmdi-arrow-left"></i>
                  </div>
                  <div class="avatar">
                    <img src="avatar.jpg" alt="Diego Tauchert">
                  </div>
                  <div class="name">
                    <span>(99)99999-1111</span>
                    <span class="status">online</span>
                  </div>
                  <div class="actions more">
                    <i class="zmdi zmdi-more-vert"></i>
                  </div>
                  <div class="actions attachment">
                    <i class="zmdi zmdi-attachment-alt"></i>
                  </div>
                  <div class="actions">
                    <i class="zmdi zmdi-phone"></i>
                  </div>
                </div>
                <!--campo mensagens-->
                <div class="conversation">
                  <div class="conversation-container">
                    <div class="message received"><!--mensagem recebida!-->
                      Tá podendo falar?
                      <span class="metadata">
                        <span class="time">18:35 PM</span>
                      </span>
                    </div>
                    <div class="message sent"><!--mensagem enviada!-->
                      Oi, Fernando
                      <span class="metadata">
                        <span class="time">18:42 PM</span><!--horário de envio!-->
                        <span class="tick read">
                          <i class="zmdi zmdi-check"></i><!--mensagem verificada!-->
                          <i class="zmdi zmdi-check"></i>
                        </span>
                      </span>
                    </div>
                    <div class="message sent">
                      posso
                      <span class="metadata">
                        <span class="time">18:42 PM</span>
                        <span class="tick read">
                          <i class="zmdi zmdi-check"></i>
                          <i class="zmdi zmdi-check"></i>
                        </span>
                      </span>
                    </div>
                    <div class="message received">
                      Tá muito ocupado?
                      <span class="metadata">
                        <span class="time">18:42 PM</span>
                      </span>
                    </div>
                    <div class="message received">
                      Preciso de um favor estou com um pequeno probleminha aqui nada grave
                      <span class="metadata">
                        <span class="time">18:43 PM</span>
                      </span>
                    </div>
                    <div class="message sent">
                      diga
                      <span class="metadata">
                        <span class="time">18:44 PM</span>
                        <span class="tick read">
                          <i class="zmdi zmdi-check"></i>
                          <i class="zmdi zmdi-check"></i>
                        </span>
                      </span>
                    </div>
                    <div class="message sent">
                      se eu puder ajudar..
                      <span class="metadata">
                        <span class="time">18:44 PM</span>
                        <span class="tick read">
                          <i class="zmdi zmdi-check"></i>
                          <i class="zmdi zmdi-check"></i>
                        </span>
                      </span>
                    </div>
                    <div class="message received">
                      Consegue fazer um pagamento via transferência para mim? Fiz duas hoje e excedeu o meu limite diário, antes das 16:00 hrs te deposito novamente
                      <span class="metadata">
                        <span class="time">18:45 PM</span>
                      </span>
                    </div>
                    <div class="message sent">
                      depende do valor...
                      <span class="metadata">
                        <span class="time">18:46 PM</span>
                        <span class="tick read">
                          <i class="zmdi zmdi-check"></i>
                          <i class="zmdi zmdi-check"></i>
                        </span>
                      </span>
                    </div>
                    <div class="message received">
                      2.500,00
                      <span class="metadata">
                        <span class="time">18:46 PM</span>
                      </span>
                    </div>
                    <div class="message received">
                      Se não for te atrapalhar, hoje mesmo te retorno..
                      <span class="metadata">
                        <span class="time">18:46 PM</span>
                      </span>
                    </div>
                    <div class="message sent">
                      dá certo sim
                      <span class="metadata">
                        <span class="time">18:47 PM</span>
                        <span class="tick read">
                          <i class="zmdi zmdi-check"></i>
                          <i class="zmdi zmdi-check"></i>
                        </span>
                      </span>
                    </div>
                    <div class="message sent">
                      me manda a conta!
                      <span class="metadata">
                        <span class="time">18:47 PM</span>
                        <span class="tick read">
                          <i class="zmdi zmdi-check"></i>
                          <i class="zmdi zmdi-check"></i>
                        </span>
                      </span>
                    </div>
                    <div class="message sent">
                      pode ser via PIX?
                      <span class="metadata">
                        <span class="time">18:48 PM</span>
                        <span class="tick read">
                          <i class="zmdi zmdi-check"></i>
                          <i class="zmdi zmdi-check"></i>
                        </span>
                      </span>
                    </div>
                    <div class="message received">
                      pode sim!
                      <span class="metadata">
                        <span class="time">18:49 PM</span>
                      </span>
                    </div>
                    <div class="message received">
                      aqui a chave PIX 👇
                      <span class="metadata">
                        <span class="time">18:49 PM</span>
                      </span>
                    </div>
                    <div class="message received">
                      7282-KAnud6-34Dna873-mqef8-iU1ZbI
                      <span class="metadata">
                        <span class="time">18:50 PM</span>
                      </span>
                    </div>
                    <div class="message sent">
                      blz, ja te mando o comprovante!
                      <span class="metadata">
                        <span class="time">18:51 PM</span>
                        <span class="tick read">
                          <i class="zmdi zmdi-check"></i>
                          <i class="zmdi zmdi-check"></i>
                        </span>
                      </span>
                    </div>
                    <div class="message received">
                      Ok
                      <span class="metadata">
                        <span class="time">18:52 PM</span>
                      </span>
                    </div>
                  </div>
                  <form class="conversation-compose">
                    <div class="emoji">
                      <i class="zmdi zmdi-mood"></i>
                    </div>
                    <input class="input-msg" name="input" placeholder="Type a message" autofocus autocomplete="off" />
                    <div class="photo">
                      <i class="zmdi zmdi-camera"></i>
                    </div>
                    <button class="send">
                      <div class="circle">
                        <i class="zmdi zmdi-mail-send"></i>
                      </div>
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
      </div>
      </div>
    </div>
  </div>
</body>
</html>