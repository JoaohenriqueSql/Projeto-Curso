jQuery(document).ready(function($){
	//submenu abrir-fechar no celular
	$('.cd-main-nav').on('click', function(event){
		if($(event.target).is('.cd-main-nav')) $(this).children('ul').toggleClass('is-visible');
	});
});
