<?php
//todas as variáveis ​​aqui definidas estão acessíveis em todos os ficheiros que incluem este
$con= new mysqli('localhost','root','','seguranca_dados')or die("Could not connect to mysql".mysqli_error($con));

?>